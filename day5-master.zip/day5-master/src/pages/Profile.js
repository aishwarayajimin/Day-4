import React from 'react';

const Profile = () => {
  return (
    <div className="mt-5">
      <h2>Profile</h2>
      <p>This is your profile page.</p>
    </div>
  );
};

export default Profile;
