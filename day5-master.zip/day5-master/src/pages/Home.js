import React from 'react';

const Home = () => {
  return (
    <div>
      <h2>Home</h2>
      <p>Welcome to the Task Manager App!</p>
    </div>
  );
};

export default Home;
